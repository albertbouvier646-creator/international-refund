International Refund - One-page Next.js starter. Copy into your Next.js project root and run npm install && npm run dev
